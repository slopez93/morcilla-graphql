"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.graphql = void 0;
require("reflect-metadata");
const server_1 = require("@apollo/server");
const aws_lambda_1 = require("@as-integrations/aws-lambda");
const typedi_1 = __importDefault(require("typedi"));
const type_graphql_1 = require("type-graphql");
const FoodsResolver_1 = require("./infrastructure/resolvers/FoodsResolver");
const di_1 = require("./config/di");
const ShoppingListResolver_1 = require("./infrastructure/resolvers/ShoppingListResolver");
const bootstrap = async () => {
    const schema = await (0, type_graphql_1.buildSchema)({
        resolvers: [FoodsResolver_1.FoodsResolver, ShoppingListResolver_1.ShoppingListResolver],
        // register 3rd party IOC container
        container: typedi_1.default,
    });
    (0, di_1.registerDependencies)(typedi_1.default);
    // Create GraphQL server
    const server = new server_1.ApolloServer({ schema });
    return server;
};
const graphql = async (event, context, callback) => {
    const server = await bootstrap();
    return (0, aws_lambda_1.startServerAndCreateLambdaHandler)(server)(event, context, callback);
};
exports.graphql = graphql;
