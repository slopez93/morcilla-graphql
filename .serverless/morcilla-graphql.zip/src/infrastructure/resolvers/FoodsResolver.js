"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FoodsResolver = void 0;
const type_graphql_1 = require("type-graphql");
const typedi_1 = require("typedi");
const Food_1 = require("../../domain/entities/Food");
const FoodsRepository_1 = require("../../domain/repositories/FoodsRepository");
const CreateFoodInputType_1 = require("./inputs/CreateFoodInputType");
let FoodsResolver = class FoodsResolver {
    repository;
    constructor(repository) {
        this.repository = repository;
    }
    async foods() {
        return await this.repository.getAll();
    }
    async createFood(createFoodInput, pubSub) {
        const foods = await this.repository.getAll();
        const { name, url } = createFoodInput;
        const newFood = new Food_1.Food((Number(foods[foods.length - 1].id) + 1).toString(), name, url);
        await this.repository.save(newFood);
        await pubSub.publish("NEW_FOOD_CREATED", newFood);
        return newFood;
    }
};
__decorate([
    (0, type_graphql_1.Query)((returns) => [Food_1.Food]),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], FoodsResolver.prototype, "foods", null);
__decorate([
    (0, type_graphql_1.Mutation)((returns) => Food_1.Food),
    __param(0, (0, type_graphql_1.Arg)("data")),
    __param(1, (0, type_graphql_1.PubSub)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [CreateFoodInputType_1.CreateFoodInputType,
        type_graphql_1.PubSubEngine]),
    __metadata("design:returntype", Promise)
], FoodsResolver.prototype, "createFood", null);
FoodsResolver = __decorate([
    (0, typedi_1.Service)(),
    (0, type_graphql_1.Resolver)(Food_1.Food),
    __param(0, (0, typedi_1.Inject)(FoodsRepository_1.FOOD_REPOSITORY)),
    __metadata("design:paramtypes", [Object])
], FoodsResolver);
exports.FoodsResolver = FoodsResolver;
