"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ShoppingListResolver = void 0;
const type_graphql_1 = require("type-graphql");
const typedi_1 = require("typedi");
const ShoppingList_1 = require("../../domain/entities/ShoppingList");
const ShoppingListRepository_1 = require("../../domain/repositories/ShoppingListRepository");
let ShoppingListResolver = class ShoppingListResolver {
    repository;
    constructor(repository) {
        this.repository = repository;
    }
    async shoppingList() {
        return await this.repository.getShoppingListByDate(new Date());
    }
    newFoodAdded(notificationPayload) {
        console.warn("NEW FOOD ADDED EVENT");
        return notificationPayload;
    }
};
__decorate([
    (0, type_graphql_1.Query)((returns) => ShoppingList_1.ShoppingList),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], ShoppingListResolver.prototype, "shoppingList", null);
__decorate([
    (0, type_graphql_1.Subscription)({ topics: "NEW_FOOD_CREATED" }),
    __param(0, (0, type_graphql_1.Root)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [ShoppingList_1.ShoppingList]),
    __metadata("design:returntype", ShoppingList_1.ShoppingList)
], ShoppingListResolver.prototype, "newFoodAdded", null);
ShoppingListResolver = __decorate([
    (0, typedi_1.Service)(),
    (0, type_graphql_1.Resolver)(),
    __param(0, (0, typedi_1.Inject)(ShoppingListRepository_1.SHOPPING_REPOSITORY)),
    __metadata("design:paramtypes", [Object])
], ShoppingListResolver);
exports.ShoppingListResolver = ShoppingListResolver;
