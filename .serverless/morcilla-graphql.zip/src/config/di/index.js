"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.registerDependencies = void 0;
const FoodsRepository_1 = require("../../domain/repositories/FoodsRepository");
const ShoppingListRepository_1 = require("../../domain/repositories/ShoppingListRepository");
const InMemoryFoodsRepository_1 = require("../../infrastructure/persistence/InMemoryFoodsRepository");
const InMemoryShoppingListRepository_1 = require("../../infrastructure/persistence/InMemoryShoppingListRepository");
const registerDependencies = (container) => {
    container.set(FoodsRepository_1.FOOD_REPOSITORY, new InMemoryFoodsRepository_1.InMemoryFoodsRepository());
    container.set(ShoppingListRepository_1.SHOPPING_REPOSITORY, new InMemoryShoppingListRepository_1.InMemoryShoppingListRepository());
};
exports.registerDependencies = registerDependencies;
