"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SHOPPING_REPOSITORY = void 0;
exports.SHOPPING_REPOSITORY = Symbol("SHOPPING_REPOSITORY").toString();
