"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FOOD_REPOSITORY = void 0;
exports.FOOD_REPOSITORY = Symbol("FOOD_REPOSITORY").toString();
